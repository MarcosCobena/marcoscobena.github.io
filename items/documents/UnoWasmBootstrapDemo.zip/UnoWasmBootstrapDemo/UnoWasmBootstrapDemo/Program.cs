﻿using System;
using System.Net.Http;
using WaveEngine.Common.Math;
using WebAssembly;

namespace UnoWasmBootstrapDemo
{
    class Program
    {
        static readonly Slide[] slides;

        static int currentSlideIndex;
        static int previousSlideIndex;

        static Program()
        {
            slides = new Slide[]
            {
                // Hello, World!
                new Slide(
                    "<button id='hello-world-demo'>Hello, World!</button>")
                {
                    Initialize = () =>
                    {
                        SubscribeButtonOnClick("hello-world-demo", _ =>
                        {
                            Console.WriteLine("Hello, World!");
                        });
                    },
                    Uninitialize = () =>
                    {
                        UnsubscribeButtonOnClick("hello-world-demo");
                    }
                },
                // Can we create a Matrix from Wave Engine's NuGet?
                new Slide(
                    "<button id='wave-engine-matrix-demo'>Wave Engine's Matrix</button>")
                {
                    Initialize = () =>
                    {
                        SubscribeButtonOnClick("wave-engine-matrix-demo", _ =>
                        {
                            var matrix = Matrix.Identity;
                            Console.WriteLine($"Identity: {matrix}");
                            var determinant = matrix.Determinant();
                            Console.WriteLine($"Identity's determinant: {determinant}");
                        });
                    },
                    Uninitialize = () =>
                    {
                        UnsubscribeButtonOnClick("wave-engine-matrix-demo");
                    }
                },
                // Let's fetch a TXT file and log its content
                // TODO force error to notice how it's internally implemented through the call stack
                new Slide(
                    "<button id='httpclient-demo'>HttpClient</button>")
                {
                    Initialize = () =>
                    {
                        SubscribeButtonOnClick("httpclient-demo", async _ =>
                        {
                            var httpClient = new HttpClient
                            { 
                                // Must be equal to avoid CORS-related error
                                BaseAddress = new Uri("http://127.0.0.1:8080/") 
                            };
                            var response = await httpClient.GetAsync("Assets/Foo.txt");
                            var content = await response.Content.ReadAsStringAsync();
                            Console.WriteLine($"Content: {content}");
                        });
                    },
                    Uninitialize = () =>
                    {
                        UnsubscribeButtonOnClick("httpclient-demo");
                    }
                }
            };

            currentSlideIndex = -1;
            previousSlideIndex = -1;
        }

        static void Main(string[] args)
        {
            SubscribeButtonOnClick("previous-slide", _ => ShowPreviousSlide());
            SubscribeButtonOnClick("next-slide", _ => ShowNextSlide());

            ShowNextSlide();
        }

        static void ShowNextSlide() => ShowSlideAt(++currentSlideIndex);

        static void ShowPreviousSlide() => ShowSlideAt(--currentSlideIndex);

        static void ShowSlideAt(int index)
        {
            if (index < 0)
            {
                currentSlideIndex = 0;
                return;
            }

            if (index >= slides.Length)
            {
                currentSlideIndex = slides.Length - 1;
                return;
            }

            if (previousSlideIndex >= 0)
            {
                var previousSlide = slides[previousSlideIndex];
                previousSlide.Uninitialize?.Invoke();
            }

            var currentSlide = slides[index];

            using (var document = (JSObject)Runtime.GetGlobalObject("document"))
            using (var slideContent = (JSObject)document.Invoke("getElementById", "slide-content"))
            {
                var html = currentSlide.Html;

                if (!string.IsNullOrWhiteSpace(currentSlide.SourceUrl))
                {
                    html += $"\n<a href='{currentSlide.SourceUrl}' target='_blank'>Source</a>";
                }

                slideContent.SetObjectProperty("innerHTML", html);
            }

            currentSlide.Initialize?.Invoke();

            previousSlideIndex = currentSlideIndex;
        }

        static void SubscribeButtonOnClick(string buttonId, Action<JSObject> action)
        {
            using (var document = (JSObject)Runtime.GetGlobalObject("document"))
            using (var button = (JSObject)document.Invoke("getElementById", buttonId))
            {
                button.SetObjectProperty("onclick", action);
            }
        }

        static void UnsubscribeButtonOnClick(string buttonId)
        {
            using (var document = (JSObject)Runtime.GetGlobalObject("document"))
            using (var button = (JSObject)document.Invoke("getElementById", buttonId))
            {
                button.SetObjectProperty("onclick", null);
            }
        }

        class Slide
        {
            public Slide(string html)
            {
                Html = html;
            }

            public string Html { get; }

            public Action Initialize { get; set; }

            public string SourceUrl { get; set; }

            public Action Uninitialize { get; set; }
        }
    }
}
